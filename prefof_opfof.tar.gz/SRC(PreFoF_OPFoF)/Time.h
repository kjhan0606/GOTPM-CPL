float WTIME();
float WALLCLOCK();
